﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

internal class zwierze
{
    public int Id { get; set; }
    public string Rasa { get; set; }
    public string Imie { get; set; }
    public int Wiek { get; set; }
    public string Zachowanie { get; set; }
}