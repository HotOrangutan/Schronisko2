﻿using OpcjeMenu;

Opcje.menu(); //wywołuje funkcję menu() w pliku Opcje.cs